USERNAME_MAX_LENGHT = 150
EMAIL_MAX_LENGHT = 254
FIRST_NAME_MAX_LENGHT = 150
LAST_NAME_MAX_LENGHT = 150
ROLE_MAX_LENGHT = 16

LOGIN_ERROR_MESSAGE = (
    'Логин может содержать только английские '
    'буквы, цифры или символы "@", ".", "_", "+", "-".'
)